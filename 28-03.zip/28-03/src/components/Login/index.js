import React, { Component } from 'react';
// import LoginContent from './LoginContent';

//import './login.css';


class Login extends Component {
	render() {
		return (
			<div className="outer">
				<LoginContent/>
					<div className="login">
						<div className="Commant-text">Command Center Login</div>
						<Row>
							<form onSubmit={this.login}>
								<FormGroup controlId="username" validationState={ formSubmitted ? (errors.username ? 'error' : 'success') : null }>
									<div className="lefttext">USERNAME</div>
									<FormControl type="text" name="username" className="inputclass" placeholder="USERNAME" onChange={this.handleInputChange} />
									<span className="input_user"></span>
								{ errors.username &&
									<HelpBlock>{errors.username}</HelpBlock>
								}
								</FormGroup >
								<FormGroup controlId="password" validationState={ formSubmitted ? (errors.password ? 'error' : 'success') : null }>
									<div className="lefttext">PASSWORD</div>
									<FormControl type="password" name="password" className="inputclass" placeholder="PASSWORD" onChange={this.handleInputChange} />
									<span className="input_pass"></span>
								{ errors.password &&
									<HelpBlock>{errors.password}</HelpBlock>
								}
								</FormGroup>
								<div className="checkbox leftalign"><input type="checkbox" className="ckeckboxclass" name="remember"/><span className="remmember"> Remember me</span></div>
								<input type="submit" className="loginbutton" value="Login"/>
							</form>
						</Row>
					</div>
			</div>
		
		);
	}
}

export default Login;